import streamlit as st
import pdfplumber
import pandas as pd
import json,re
import pytesseract
from typing import Optional
from pydantic import BaseModel,Field, create_model
from langchain_groq import ChatGroq
from pdf2image import convert_from_bytes

# Helper Function
def extracttextfrompdf(uploadedfile)->str:
    rawtext=""
    uploadedfile.seek(0)
    pdf_bytes = uploadedfile.read()
    uploadedfile.seek(0)
    with pdfplumber.open(uploadedfile) as pdf:
        for page in pdf.pages:
            text=page.extract_text()
            if text:
                rawtext+=text+"\n"
    try:
        images = convert_from_bytes(pdf_bytes, dpi=300)
        ocr_text = ""
        for img in images:
            ocr_text += pytesseract.image_to_string(img) + "\n"
        if ocr_text.strip():
            rawtext += "\n--- OCR Extracted Text ---\n" + ocr_text
    except Exception:
        pass
    return rawtext

# Auto-detect document type
def detectdocumenttype(text: str)->dict:
    llm=ChatGroq(model="llama-3.3-70b-versatile",temperature=0.0)
    prompt=f"""Analyze the following document text and retuen a JSON object with:
    1. "doc_type":a short label like "Resume","Invoice","Medical Bill","Bank Statement","Legal Contract",etc.
    2. "suggested_fields": a list of 5-8 relevant field label strings that are most useful to extract from this document type.
    Respond ONLY with valid JSON, no markdown, no explanation.
    Document text (first 1500 chars):
    {text[:500000]}
    """
    response=llm.invoke([("human",prompt)])
    raw=re.sub(r"```json|```","",response.content.strip()).strip()
    try:
        return json.loads(raw)
    except Exception:
        return {"doc_type":"Document","suggested_fields":["Field 1","Field 2","Field 3"]}

# Dynamic Extraction
def extractfields(text:str,fields:list[str])->pd.DataFrame:
    fielddefs={}
    keytolabel={}
    for idx,f in enumerate(fields):
        f=str(f)
        key = re.sub(r"[^a-z0-9]+", "_", f.strip().lower()).strip("_")
        if not key:
            key = f"field_{idx}"
        if key in keytolabel:
            key = f"{key}_{idx}"
        fielddefs[key]=(Optional[str],Field(None,description=f"Extract:{f}"))
        keytolabel[key]=f
    DynamicModel=create_model("DynamicDoc",**fielddefs)
    llm=ChatGroq(model="llama-3.3-70b-versatile",temperature=0.0)
    structuredllm=llm.with_structured_output(DynamicModel)
    fieldlist="\n".join(f"-{f}" for f in fields)
    systemprompt=(
        "You are an expert document data extraction AI.\n"
        "Your job is to extract ONLY the exact value for each requested field from the document.\n\n"
        "STRICT RULES:\n"
        "- Return ONLY the value itself. Never include the field name, label, or surrounding text.\n"
        "- Example: if asked for 'Invoice Number' and the document says 'Invoice No. BBL/34/2324', return 'BBL/34/2324' only.\n"
        "- Example: if asked for 'Date' and the document says 'Dated 5-May-2023', return '5-May-2023' only.\n"
        "- Example: if asked for 'Total Amount' and the document says 'Total 55,460.00', return '55,460.00' only.\n"
        "- Do NOT copy the field label into the value.\n"
        "- Do NOT include extra words, context, or explanation.\n"
        "- However, ALWAYS preserve the COMPLETE value exactly as written, including branch names, codes, suffixes, or qualifiers that are part of the same value.\n"
        "- Example: if asked for 'Bank Name' and the document says 'Bank Name : HDFC Bank - 22', return 'HDFC Bank - 22' (not just 'HDFC Bank') because '- 22' is part of the same value, not separate context.\n"
        "- Example: if asked for 'Branch & IFS Code' and the document says 'Branch & IFS Code : Aminjikarai & HDFC0000441', return 'Aminjikarai & HDFC0000441' in full.\n"
        "- Only strip the field's own label/prefix (like 'Bank Name :' or 'Invoice No.'). Never strip parts of the value itself.\n"
        "- If a field is not found in the document, return null.\n\n"
        "Fields to extract:\n" + fieldlist
    )
    message=[
        ("system",systemprompt),
        ("human",f"Extract all specified fields from this document:\n\n{text}")
    ]
    result=structuredllm.invoke(message)
    rows=[
        {"Field":keytolabel.get(k,k),"Extracted Value":v}
        for k,v in result.model_dump().items()
    ]
    return pd.DataFrame(rows)

# Main
def main():
    st.set_page_config(page_title="AI Extractor",layout="centered")
    st.title("AI Powered Extractor")
    st.write("Upload any document, define your fields and extract structured data instantly.")

    # Upload
    st.subheader("Step 1 - Upload Document")
    uploadedfile=st.file_uploader("Choose PDF File",type=["pdf"])
    if uploadedfile is None:
        for key in ("doc_text","doc_type","fields","result_df","last_file"):
            st.session_state.pop(key,None)
        return
    
    # Reading PDF once per file
    if st.session_state.get("last_file")!=uploadedfile.name:
        with st.spinner("Reading PDF..."):
            try:
                text=extracttextfrompdf(uploadedfile)
                st.session_state.doc_text=text
                st.session_state.last_file=uploadedfile.name
                for key in ("doc_type","result_df"):
                    st.session_state.pop(key,None)
            except Exception as e:
                st.error(f"Could not read PDF:{e}")
                return
    doc_text=st.session_state.doc_text
    if not doc_text.strip():
        st.warning("No readable text found in this PDF.")
        return
       
    # Auto-detect document type
    if "doc_type" not in st.session_state:
        with st.spinner("Detect document type..."):
            st.session_state.doc_type=detectdocumenttype(doc_text)
    st.success(f"Document detected as: **{st.session_state.doc_type}**")

    # Field editor
    st.subheader("Step 2 - Fields to Extract")
    st.caption("Type any field you want")
    userinput=st.text_input(
        "Fields to extract",
        placeholder="e.g. Name, DOB, Mobile Number, ..."
    )

    # Extract
    st.subheader("Step 3 - Extract")
    validfields=[f.strip() for f in userinput.split(",") if f.strip()] if userinput else []
    if not validfields:
        st.info("Type the fields you want to extract above, then click Extract.")
        return
    st.write(f"Ready to extract **{len(validfields)}** field(s):"+", ".join(f"'{f}'" for f in validfields))
    if st.button(f"Extract {len(validfields)} Field{'s' if len(validfields)!=1 else ''}"):
        with st.spinner("Extracting with AI..."):
            try:
                df=extractfields(doc_text,validfields)
                st.session_state.result_df=df
            except Exception as e:
                st.error(f"Extraction failed: {e}")
                st.info("Make sure your GROQ_API_KEY environment variable in set and valid.")

    # Results
    if "result_df" in st.session_state:
        df=st.session_state.result_df
        st.success(f"{len(df)} field(s) extracted successfully.")
        import json
        data=df.set_index("Field")["Extracted Value"].to_dict()
        cleandata={k:(None if v is None or v=="-" else v) for k,v in data.items()}
        st.code(json.dumps(cleandata,indent=2,ensure_ascii=False),language="json")
        with st.expander("View Raw PDF Text"):
            st.text(doc_text[:30000000]+("..." if len(doc_text)>30000000 else ""))

if __name__=="__main__":
    main()