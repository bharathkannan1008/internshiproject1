import streamlit as st
import mysql.connector as ms
from mysql.connector import Error
import pandas as pd
import plotly.express as px
import base64
import os

# Set Page Configuration
st.set_page_config(page_title="Ticketing System",layout="wide")

# Database Configuration and Helper Functions
def getdbconnection():
    try:
        x=ms.connect(
            host="localhost",
            user="root",
            password="bharathkannan2005",
            database="ticketing_system"
        )
        return x
    except Error as e:
        st.error(f"Database Connection Error: {e}")
        return None

def verifyuser(email,password):
    x=getdbconnection()
    if x:
        cur=x.cursor(dictionary=True)
        query="SELECT user_id, full_name, email, role, department_id FROM users WHERE email= %s AND password= %s"
        cur.execute(query,(email,password))
        user=cur.fetchone()
        cur.close()
        x.close()
        return user
    return None

def checkemailexists(email):
    x=getdbconnection()
    if x:
        cur=x.cursor()
        query="SELECT user_id FROM users WHERE email=%s"
        cur.execute(query,(email,))
        result=cur.fetchone()
        cur.close()
        x.close()
        return result is not None
    return False

def fetchdepartmentslist():
    x=getdbconnection()
    if x:
        cur=x.cursor(dictionary=True)
        cur.execute("SELECT department_id,department_name FROM departments")
        result=cur.fetchall()
        cur.close()
        x.close()
        return result
    return []

def fetchticketreplies(ticket_id,internal_only=False,public_only=False):
    x=getdbconnection()
    df=pd.DataFrame()
    if x:
        notefilter=""
        if internal_only:
            notefilter="AND r.is_internal_note=1"
        elif public_only:
            notefilter="AND r.is_internal_note=0"
        query=f"""
            SELECT r.created_at,u.full_name as Author,u.role,r.message,r.is_internal_note
            FROM ticket_replies r JOIN users u ON r.user_id=u.user_id
            WHERE r.ticket_id={int(ticket_id)} {notefilter}
            ORDER BY r.created_at ASC
        """
        df=pd.read_sql(query,x)
        x.close()
    return df

def updatepassword(email,new_password):
    x=getdbconnection()
    if x:
        try:
            cur=x.cursor()
            query="UPDATE users SET password=%s WHERE email=%s"
            cur.execute(query,(new_password,email))
            x.commit()
            cur.close()
            return True
        except Error as e:
            st.error(f"Failed to execute database update: {e}")
            return False
        finally:
            x.close()
    return False

def fetchslapolicies():
    x=getdbconnection()
    if x:
        cur=x.cursor(dictionary=True)
        cur.execute("SELECT sla_id,policy_name FROM sla_policies")
        result=cur.fetchall()
        cur.close()
        x.close()
        return result
    return []

# Shared Image helpers
def _imgb64(path):
    ext=os.path.splitext(path)[1].lower().lstrip(".")
    mime={"jpg":"jpeg","jpeg":"jpeg","png":"png",
          "gif":"gif","webp":"webp"}.get(ext,"png")
    with open(path,"rb") as f:
        data=base64.b64encode(f.read()).decode()
    return f"data:image/{mime};base64,{data}"

def makeimgcell(path):
    if path and str(path)!='None' and os.path.exists(str(path)):
        src=_imgb64(path)
        uid=abs(hash(path))% 10_000_000
        return (
            f'<label for="lb{uid}" style="cursor:pointer;">'
            f'  <img src="{src}" style="height:48px;border-radius:4px;'
            f'       border:1px solid #555;vertical-align:middle;" />'
            f'  &nbsp;<span style="color:#7B9EFF;text-decoration:underline;">View Screenshot</span>'
            f'</label>'
            f'<input type="checkbox" id="lb{uid}" style="display:none;">'
            f'<label for="lb{uid}" style="'
            f'  display:none;position:fixed;top:0;left:0;width:100%;height:100%;'
            f'  background:rgba(0,0,0,0.85);z-index:9999;'
            f'  justify-content:center;align-items:center;cursor:zoom-out;" '
            f'  id="overlay{uid}">'
            f'  <img src="{src}" style="max-width:90%;max-height:90%;'
            f'       border-radius:8px;box-shadow:0 4px 40px #000;" />'
            f'</label>'
            f'<style>'
            f'  #lb{uid}:checked ~ label#overlay{uid}{{display:flex!important;}}'
            f'</style>'
        )
    return '<span style="color:#888;">No image</span>'

# Custom UI Styling
def injectcustom():
    st.markdown("""
        <style>
            /* Allow fixed-position lightbox to cover the full viewport */
            .stApp { overflow: visible !important; }
            iframe[title="st.html"], .element-container iframe {
                overflow: visible !important;
            }
            /* Center-align all HTML table headers */
            table thead th {
                text-align: center !important;
            }
            .auth-bg {
                background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
                padding: 2.5rem;
                border-radius: 16px;
                box-shadow: 0 12px 30px rgba(0,0,0,0.3);
                margin-bottom: 20px;
            }
            div[data-testid="stMetricValue"] {
                font-size: 32px;
                color: #2563EB;
                font-weight: bold;    
            }
            .stButton>button {
                background: linear-gradient(45deg, #EC4899, #8B5CF6);
                color: white !important;
                border: none;
                padding: 0.6rem 2 rem;
                border-radius: 30px
                font-weight: 600;
                transition: all 0.3s ease;    
            }
            .stButton>button:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 20px rgba(139,92,246,0.4);    
            }
            .stApp {
                overflow:visible !important;
            }
            iframe[title="st.html"], .element-container iframe {
                overflow: visible !important;
            }
        </style>
    """,unsafe_allow_html=True)
injectcustom()

# Routing and State Controls
if 'logged_in' not in st.session_state:
    st.session_state.logged_in=False
    st.session_state.user_info=None
if 'auth_mode' not in st.session_state:
    st.session_state.auth_mode='Login'

# Handles Auth Pages ( Login / Signup / Forgot Password )
def authpage():
    _,col2,_=st.columns([1,1.4,1])
    with col2:
        if st.session_state.auth_mode=='Login':
            st.markdown('<div class="auth-bg">',unsafe_allow_html=True)
            st.title("Ticketing Portal")
            st.write("Sign in to access your custom desk dashboard.")
            email=st.text_input("Email Address",key="login_email")
            password=st.text_input("Password",type="password",key="login_pass")
            if st.button("Sign in",use_container_width=True):
                user=verifyuser(email,password)
                if user:
                    st.session_state.logged_in=True
                    st.session_state.user_info=user
                    st.success(f"Successfully Authenticated as {user['full_name']}!")
                    st.rerun()
                else:
                    st.error("Invalid email or password!")
            st.markdown('<hr style="border-color: rgba(255,255,255,0.2);">',unsafe_allow_html=True)
            c1,c2=st.columns(2)
            with c1:
                if st.button("Created Account",key="go_signup"):
                    st.session_state.auth_mode='Signup'
                    st.rerun()
            with c2:
                if st.button("Forgot Password?",key="go_forgot"):
                    st.session_state.auth_mode='Forgot'
                    st.rerun()
            st.markdown('</div>',unsafe_allow_html=True)
        elif st.session_state.auth_mode=='Signup':
            st.markdown('<div class="auth-bg">',unsafe_allow_html=True)
            st.title("Account Registration")
            regname=st.text_input("Full Name")
            regemail=st.text_input("Email Address")
            regpass=st.text_input("Choose Secure Password",type="password")
            regrole=st.selectbox("Assign Account System Role",["Customer","Agent"])
            depts=fetchdepartmentslist()
            if depts:
                deptoptions={d['department_name']:d['department_id'] for d in depts}
                selecteddeptname=st.selectbox("Select Department Name",list(deptoptions.keys()))
                deptidtosave=deptoptions[selecteddeptname]
            else:
                st.warning("No departments found in database system setup.")
                deptidtosave=None
            
            if st.button("Register",use_container_width=True):
                if regname and regemail and regpass and deptidtosave:
                    x=getdbconnection()
                    if x:
                        try:
                            cur=x.cursor()
                            query="""
                                INSERT INTO users(full_name,email,role,department_id,created_at,password) 
                                VALUES(%s,%s,%s,%s,NOW(),%s)
                            """
                            cur.execute(query,(regname,regemail,regrole,deptidtosave,regpass))
                            x.commit()
                            st.success("Proceed to Login")
                            st.session_state.auth_mode='Login'
                            st.rerun()
                        except ms.IntegrityError:
                            st.error("This email address is already registered!")
                        finally:
                            x.close()
                else:
                    st.warning("Please complete all available data fields.")
            if st.button("Return to Login Portal"):
                st.session_state.auth_mode='Login'
                st.rerun()
            st.markdown('</div>',unsafe_allow_html=True)
        elif st.session_state.auth_mode=='Forgot':
            st.markdown('<div class="auth-bg">',unsafe_allow_html=True)
            st.title("Forgot Password")
            st.write("Reser yout password")
            femail=st.text_input("Enter Registered Email Address")
            newpass=st.text_input("Type New Secure Password",type="password")
            confirmpass=st.text_input("Confirm New Secure Password",type="password")
            if st.button("Update Password",use_container_width=True):
                if femail and newpass and confirmpass:
                    if newpass!=confirmpass:
                        st.error("Passwords do not match!")
                    else:
                        if checkemailexists(femail):
                            if updatepassword(femail,newpass):
                                st.success("Use your new credentials to sign in.")
                                st.session_state.auth_mode='Login'
                                st.rerun()
                            else:
                                st.error("Account email record is not found.")
                else:
                    st.warning("Please populate all necessary validation targets.")
            if st.button("Return to Login Portal",key="forgot_back"):
                st.session_state.auth_mode='Login'
                st.rerun()
            st.markdown('</div>',unsafe_allow_html=True)

# Dashboard shared query
def fetchdataframe(query):
    x=getdbconnection()
    df=pd.DataFrame()
    if x:
        df=pd.read_sql(query,x)
        x.close()
    return df

# Dashboard
def admindashboard():
    st.title("ADMIN DASHBOARD")
    st.markdown(f"Welcome back, System Admin **{st.session_state.user_info['full_name']}**")
    ticketdf=fetchdataframe("SELECT * FROM tickets")
    totaltickets=len(ticketdf)
    opentickets=len(ticketdf[ticketdf['status']=='Open']) if totaltickets else 0
    resolvedtickets=len(ticketdf[ticketdf['status']=='Closed']) if totaltickets else 0
    m1,m2,m3,m4=st.columns(4)
    m1.metric("Total System Records",totaltickets)
    m2.metric("Active Open Queues",opentickets,delta="-1 Critical" if opentickets else 0)
    m3.metric("Resolved Record",resolvedtickets)
    m4.metric("Operational SLA Status","100% Valid")
    st.markdown("---")
    col1,col2=st.columns(2)
    with col1:
        st.markdown("Status Allocation Distribution")
        if not ticketdf.empty:
            fig1=px.pie(ticketdf,names='status',title="Live Ticket Status Mix",
                        color_discrete_sequence=px.colors.qualitative.Pastel)
            st.plotly_chart(fig1,use_container_width=True)
        else:
            st.info("No active tickets to generate graphs.")
    with col2:
        st.markdown("System Category Volumetrics")
        catdf=fetchdataframe("""
            SELECT c.category_name, COUNT(t.ticket_id) as total FROM categories c LEFT JOIN tickets t ON c.category_id=t.category_id GROUP BY c.category_name
        """)
        if not catdf.empty:
            fig2=px.bar(catdf,x='category_name', y='total',color='category_name',
                        title="Volume Spikes categorized by Topic Area")
            st.plotly_chart(fig2,use_container_width=True)
    col3,col4,col5=st.columns(3)
    with col3:
        st.markdown("Ticket Priority Breakdown")
        priordf=fetchdataframe(
            "SELECT priority, COUNT(*) as total FROM tickets GROUP BY priority"
        )
        if not priordf.empty:
            fig3=px.bar(priordf,x='priority',y='total',color='priority',
                        title='Tickets by Priority Level',
                        color_discrete_sequence=px.colors.qualitative.Bold)
            st.plotly_chart(fig3,use_container_width=True)
        else:
            st.info("No priority data available.")
    with col4:
        st.markdown("User Role Distribution")
        roledf=fetchdataframe(
            "SELECT role,count(*) as total FROM users GROUP BY role"
        )
        if not roledf.empty:
            fig4=px.pie(roledf,names='role',values='total',
                        title="Users by Role",
                        color_discrete_sequence=px.colors.qualitative.Safe)
            st.plotly_chart(fig4,use_container_width=True)
        else:
            st.info("No user role data available.")
    with col5:
        st.markdown("SLA Policy Usage")
        sladf=fetchdataframe("""
                SELECT sp.policy_name, COUNT(t.ticket_id) as total
                FROM sla_policies sp
                LEFT JOIN tickets t ON sp.sla_id=t.sla_id
                GROUP BY sp.policy_name
        """)
        if not sladf.empty:
            fig5=px.bar(sladf,x='policy_name',y='total',color='policy_name',
                        title="Tickets per SLA Policy",
                        color_discrete_sequence=px.colors.qualitative.Pastel)
            st.plotly_chart(fig5,use_container_width=True)
        else:
            st.info("No SLA Policy data available.")
    st.markdown("---")
    st.subheader("Unassigned Incoming Customer Tickets")
    unassigneddf=fetchdataframe("SELECT ticket_id,subject,priority,created_at,image_path FROM tickets WHERE assigned_agent_id IS NULL AND status='Open'")
    if not unassigneddf.empty:
        displayunassigned=unassigneddf.copy()
        displayunassigned['screenshot']=displayunassigned['image_path'].apply(makeimgcell)
        displayunassigned.drop(columns=['image_path'],inplace=True)
        st.write(
            displayunassigned[['ticket_id','subject','priority','created_at','screenshot']]
            .to_html(escape=False,index=False),
            unsafe_allow_html=True
        )
        colt,cola,colb=st.columns([1,1,1])
        with colt:
            selectedid=st.selectbox("Select Ticket ID to Assign",unassigneddf['ticket_id'].tolist())
        with cola:
            agentslist=fetchdataframe("SELECT user_id,full_name FROM users WHERE role='Agent'")
            agentmap={row['full_name']:row['user_id'] for _,row in agentslist.iterrows()} if not agentslist.empty else {}
            chooseagentname=st.selectbox("Assign to Available Agent",list(agentmap.keys()))
        with colb:
            st.write("")
            st.write("")
            if st.button("Confirm Agent Dispatch",use_container_width=True):
                x=getdbconnection()
                if x and chooseagentname:
                    cur=x.cursor()
                    cur.execute(
                    "UPDATE tickets SET assigned_agent_id=%s,status='In Progress',updated_at=NOW() WHERE ticket_id=%s",
                    (agentmap[chooseagentname],selectedid)
                    )
                    x.commit()
                    cur.close()
                    x.close()
                    st.success(f"Ticket #{selectedid} dispatched to agent {chooseagentname} successfully!")
                    st.rerun()
    else:
        st.info("No pending unassigned customer tickets in queue.")
    st.markdown("---")
    st.subheader("Complete System Database Explorer")
    tab1,tab2,tab3,tab4,tab5=st.tabs(["Users Table","Tickets Table","Categories Table","SLA Policies Table","Replies Log"])
    with tab1:
        st.dataframe(fetchdataframe("SELECT user_id,full_name,email,role,department_id,created_at FROM users"),use_container_width=True)
    with tab2:
        st.dataframe(fetchdataframe("SELECT * FROM tickets"),use_container_width=True)
    with tab3:
        st.dataframe(fetchdataframe("SELECT * FROM categories"),use_container_width=True)
    with tab4:
        st.dataframe(fetchdataframe("SELECT * FROM sla_policies"),use_container_width=True)
    with tab5:
        repliesadmin=fetchdataframe("SELECT * FROM ticket_replies")
        if not repliesadmin.empty:
            repliesadmin['Type']=repliesadmin['is_internal_note'].apply(
                lambda v:"Internal" if v==1 else "Public"
            )
        st.dataframe(repliesadmin,use_container_width=True)

def customerdashboard():
    customerid=st.session_state.user_info['user_id']
    st.title("CUSTOMER DASHBOARD")
    st.markdown(f"Logged in Client: **{st.session_state.user_info['full_name']}** ({st.session_state.user_info['email']})")
    if 'form_generation' not in st.session_state:
        st.session_state.form_generation=0
    subjectkey=f"ticket_subject_{st.session_state.form_generation}"
    desckey=f"ticket_desc_{st.session_state.form_generation}"
    with st.expander("Lodge New Issue Ticket Line",expanded=False):
        sub=st.text_input("Summarize Problem Subject Title",key=subjectkey)
        desc=st.text_area("Detailed Problem Context Logs",key=desckey)
        categories=fetchdataframe("SELECT category_id,category_name FROM categories")
        catoptions={row['category_name']:row['category_id'] for _,row in categories.iterrows()} if not categories.empty else{}
        selectedcat=st.selectbox("Functional Issue Area Category",list(catoptions.keys()))
        selectedpriority=st.selectbox("Priority Level",["Low","Medium","High","Critical"])
        slapolicies=fetchslapolicies()
        if slapolicies:
            slamap={p['policy_name']:p['sla_id'] for p in slapolicies}
            selectedslaname=st.selectbox("Select SLA Policy",list(slamap.keys()))
            selectedslaid=slamap[selectedslaname]
        else:
            st.warning("No SLA policies found.")
            selectedslaid=1
        uploadimage=st.file_uploader(
            "Upload Screenshot of your issue",
            type=["png","jpg","gif","webp"],
            key=f"ticket_img_{st.session_state.form_generation}"
        )
        if st.button("Submit to Help Desk"):
            if sub.strip() and desc.strip():
                savedimg=None
                if uploadimage is not None:
                    uploadir="ticket_screenshots"
                    os.makedirs(uploadir,exist_ok=True)
                    safename=(
                        f"ticket_{customerid}_{st.session_state.form_generation}"
                        f"_{uploadimage.name}"
                    )
                    savedimg=os.path.join(uploadir,safename)
                    with open(savedimg,"wb") as f:
                        f.write(uploadimage.getbuffer())
                x=getdbconnection()
                if x:
                    cur=x.cursor()
                    query="""
                        INSERT INTO tickets(subject,description,status,priority,customer_id,assigned_agent_id,category_id,sla_id,created_at,updated_at,image_path)
                        VALUES(%s,%s,'Open',%s,%s,NULL,%s,%s,NOW(),NOW(),%s)
                    """
                    cur.execute(query,(sub,desc,selectedpriority,customerid,catoptions[selectedcat],selectedslaid,savedimg))
                    x.commit()
                    cur.close()
                    x.close()
                    st.success("Ticket generated successfully! An agent will be assigned shortly.")
                    st.session_state.form_generation+=1
                    st.rerun()
            else:
                st.warning("Please complete Subject and Description before submitting.")
    st.markdown("Your Historical Support Log Entries")
    mytickets=fetchdataframe(f"SELECT ticket_id,subject,status,priority,created_at,image_path FROM tickets WHERE customer_id={customerid}")
    if not mytickets.empty:
        displaydf=mytickets.copy()
        displaydf['screenshot']=displaydf['image_path'].apply(makeimgcell)
        displaydf.drop(columns=['image_path'],inplace=True)
        st.write(
            displaydf[['ticket_id','subject','status','priority','created_at','screenshot']]
            .to_html(escape=False,index=False),
            unsafe_allow_html=True
        )
        st.markdown("#### Track Conservation Thread Threads")
        ticketmap={f"{row['subject']} (#{row['ticket_id']})":row['ticket_id'] for _,row in mytickets.iterrows()}
        selectedticketlabel=st.selectbox("Select Ticket to track updates",list(ticketmap.keys()))
        tchoice=ticketmap[selectedticketlabel]
        selrow=mytickets[mytickets['ticket_id']==tchoice].iloc[0]
        imgpath=selrow.get('image_path')
        if imgpath and str(imgpath)!='None' and os.path.exists(str(imgpath)):
            st.markdown("**Attached Screenshot:**")
            st.image(str(imgpath),width=480)
        repliesdf=fetchticketreplies(tchoice,public_only=True)
        if not repliesdf.empty:
            st.dataframe(repliesdf,use_container_width=True)
        else:
            st.info("No updates or response notes posted on this issue conversation thread yet.")
    else:
        st.info("You haven't submitted any support tickets yet.")

def agentdashboard():
    agentid=st.session_state.user_info['user_id']
    st.title("AGENT DASHBOARD")
    st.markdown(f"Agent Profile: **{st.session_state.user_info['full_name']}**")
    if 'agent_form_generation' not in st.session_state:
        st.session_state.agent_form_generation=0
    assigneddf=fetchdataframe(f"SELECT * FROM tickets WHERE assigned_agent_id={agentid}")
    pendingdf=assigneddf[assigneddf['status']!='Closed']
    completeddf=assigneddf[assigneddf['status']=='Closed']
    c1,c2=st.columns(2)
    c1.metric("My total Owned Work Items",len(assigneddf))
    c2.metric("Pending Target Actions",len(assigneddf[assigneddf['status']!='Closed']))
    st.markdown("---")
    st.markdown("Active Assigned Worklist Inboxes")
    if not pendingdf.empty:
        pendingwithimg=fetchdataframe(
            f"SELECT ticket_id,subject,status,priority,created_at,image_path "
            f"FROM tickets WHERE assigned_agent_id={agentid} AND status!='Closed'"
        )
        displaypending=pendingwithimg.copy()
        displaypending['screenshot']=displaypending['image_path'].apply(makeimgcell)
        displaypending.drop(columns=['image_path'],inplace=True)
        st.write(
            displaypending[['ticket_id','subject','status','priority','created_at','screenshot']]
            .to_html(escape=False,index=False),
            unsafe_allow_html=True
        )
        st.markdown("Perform Ticket Action Updates")
        targetid=st.selectbox("Select Ticket Target ID Key",pendingdf['ticket_id'].tolist())
        newstatus=st.selectbox("Adjust Target Lifecycle Status",["In Progress","Closed"])
        replymsg=st.text_area("Post Updates",
                              key=f"agent_reply_{st.session_state.agent_form_generation}")
        isinternal=st.checkbox("Mark as Internal Note (hidden from customer)",
                               key=f"agent_internal_{st.session_state.agent_form_generation}")
        if st.button("Apply Resolution Adjustments"):
            x=getdbconnection()
            if x:
                cur=x.cursor()
                cur.execute("UPDATE tickets SET status=%s, updated_at=NOW() WHERE ticket_id=%s",(newstatus,targetid))
                if replymsg:
                    cur.execute("""
                        INSERT INTO ticket_replies(ticket_id,user_id,message,is_internal_note,created_at)
                        VALUES (%s,%s,%s,%s,NOW())
                    """,(targetid,agentid,replymsg, 1 if isinternal else 0))
                x.commit()
                cur.close()
                x.close()
                st.session_state.agent_form_generation+=1
                st.success(f"Ticket #{targetid} updated successfully!")
                st.rerun()
        st.markdown("---")
        st.markdown("#### 💬 Conversation Thread")
        repliesdf = fetchticketreplies(targetid)
        if not repliesdf.empty:
            repliesdf['Type']=repliesdf['is_internal_note'].apply(
                lambda v:"Internal" if v==1 else "Public"
            )
            repliesdf.drop(columns=['is_internal_note'], inplace=True)
            st.dataframe(repliesdf, use_container_width=True)
        else:
            st.info("No replies posted on this ticket yet.")
    else:
        st.info("No active tickets in your queue.")
    st.markdown("---")
    st.markdown("### Completed Records Log")
    if not completeddf.empty:
        st.dataframe(completeddf[['ticket_id','subject','status','priority','created_at','updated_at']],use_container_width=True)
    else:
        st.info("No historical records have been closed or archieved by your account yet.")

# CENTRAL GATEWAY ROUTING CONTROL
if not st.session_state.logged_in:
    authpage()
else:
    st.sidebar.markdown(f"# Current User")
    st.sidebar.write(f"**Name:** {st.session_state.user_info['full_name']}")
    st.sidebar.write(f"**Role Profile:** {st.session_state.user_info['role']}")
    if st.sidebar.button("Log out Account Session",use_container_width=True):
        st.session_state.logged_in=False
        st.session_state.user_info=None
        st.session_state.auth_mode='Login'
        st.rerun()
    userrole=st.session_state.user_info['role']
    if userrole=='Admin':
        admindashboard()
    elif userrole=='Customer':
        customerdashboard()
    elif userrole=='Agent':
        agentdashboard()